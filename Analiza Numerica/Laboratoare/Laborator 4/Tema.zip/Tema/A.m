function val=A(a,b,c)
val=a-(a-b)^2/((a-b)-(b-c));
end